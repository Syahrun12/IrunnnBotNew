npm install
npm start

