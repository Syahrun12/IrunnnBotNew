<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
</head>
<body>
    <div style="text-align: center;">
        <h1>Welcome</h1>
        <img src="https://telegra.ph/file/4a727b4148415100fc260.jpg" alt="Welcome gif" width="250px">
    </div>
   <div style="text-align: center;">
    <h4 style="display: inline-block; margin-right: 20px;"><a href="https://youtube.com/@kkreyuk" style="color: red;">SUBSCRIBE</a></h4>
    <h4 style="display: inline-block;"><a href="https://t.me/kreyuk" style="color: red;">TELEGRAM</a></h4>
</div>
    <div style="text-align: center;">
        <a href="https://saweria.co/Kreyuk" target="_blank"><img src="https://i.ibb.co/NVdKQdQ/20240321-155753.png" height="70" style="border:0px;height:70px;" alt="DONATE FOR ME :V"></a>
    </div>
    <div style="text-align: center;">
       <div style="text-align: center;">
    <p style="font-size: 18px; font-weight: bold;">Hi guys,My Name is Krey</p>
</div>
    </div>
    <div style="text-align: center;">
        <a href="https://github.com/kkreyuk"><img src="https://github-readme-stats.vercel.app/api?username=kkreyuk&show_icons=true&theme=radical"></a>
    </div>
</body>
</html>